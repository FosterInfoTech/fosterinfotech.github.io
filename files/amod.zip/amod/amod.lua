--removes birds on the cast bar
MainMenuBarLeftEndCap:Hide()
MainMenuBarRightEndCap:Hide() 

--0 makes class colors in chat window
SetCVar("chatClassColorOverride", 0)

--1 shows FRIENDLY class colors in nameplates
SetCVar("ShowClassColorInFriendlyNameplate", 1)

--1 shows ENEMY class colors in nameplates
SetCVar("ShowClassColorInNameplate", 0)

--Idont think this works anymore
SetCVar("nameplateMaxDistance", 100)

--changes class color of shaman to be like retail converts RGB to hex needed for colorstr variable
RAID_CLASS_COLORS["SHAMAN"] = CreateColor(0, 0.44, 0.87, 1);
RAID_CLASS_COLORS["SHAMAN"].colorStr = RAID_CLASS_COLORS["SHAMAN"]:GenerateHexColor()

---changes max camera distance higher than GUI allows
SetCVar("cameraDistanceMaxZoomFactor", 4)